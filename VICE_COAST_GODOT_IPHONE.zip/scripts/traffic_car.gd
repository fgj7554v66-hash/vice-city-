extends Node3D

@export var travel_direction := -1.0
@export var speed := 11.0
@export var min_z := -470.0
@export var max_z := 120.0

func _ready() -> void:
	if travel_direction > 0.0:
		rotation.y = PI

func _process(delta: float) -> void:
	position.z += travel_direction * speed * delta

	if position.z < min_z:
		position.z = max_z
	elif position.z > max_z:
		position.z = min_z
