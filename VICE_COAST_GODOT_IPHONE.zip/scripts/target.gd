extends StaticBody3D

@onready var board: MeshInstance3D = $Board
var base_material: StandardMaterial3D

func _ready() -> void:
	add_to_group("targets")
	base_material = board.material_override

func on_tagged() -> void:
	var flash := StandardMaterial3D.new()
	flash.albedo_color = Color(1.0, 0.18, 0.10)
	flash.emission_enabled = true
	flash.emission = Color(1.0, 0.05, 0.01)
	flash.emission_energy_multiplier = 2.2
	board.material_override = flash
	await get_tree().create_timer(0.12).timeout
	if is_instance_valid(board):
		board.material_override = base_material
