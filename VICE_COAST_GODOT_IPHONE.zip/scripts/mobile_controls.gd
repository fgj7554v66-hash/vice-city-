extends Control

var move_vector := Vector2.ZERO
var look_delta := Vector2.ZERO

var joystick_touch := -1
var touch_modes: Dictionary = {}
var joy_center := Vector2.ZERO
var joy_knob := Vector2.ZERO
var joy_radius := 62.0

func _ready() -> void:
	add_to_group("mobile_controls")
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_process_input(true)
	queue_redraw()

func _process(_delta: float) -> void:
	var size := get_viewport_rect().size
	joy_center = Vector2(100.0, size.y - 105.0)
	joy_radius = 60.0 if size.x < 900.0 else 66.0
	queue_redraw()

func get_move_vector() -> Vector2:
	return move_vector

func consume_look_delta() -> Vector2:
	var value := look_delta
	look_delta = Vector2.ZERO
	return value

func _button_centers() -> Dictionary:
	var size := get_viewport_rect().size
	return {
		"jump": Vector2(size.x - 78.0, size.y - 178.0),
		"sprint": Vector2(size.x - 166.0, size.y - 102.0),
		"interact": Vector2(size.x - 166.0, size.y - 178.0)
	}

func _inside_button(pos: Vector2, action: String, centers: Dictionary) -> bool:
	var radius := 45.0 if action == "jump" else 40.0
	return pos.distance_to(centers[action]) <= radius

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var centers := _button_centers()

		if event.pressed:
			if event.position.distance_to(joy_center) <= joy_radius * 1.6 and joystick_touch == -1:
				joystick_touch = event.index
				touch_modes[event.index] = "joystick"
				_update_joystick(event.position)
				get_viewport().set_input_as_handled()
				return

			for action in ["jump", "sprint", "interact"]:
				if _inside_button(event.position, action, centers):
					touch_modes[event.index] = action
					Input.action_press(action)
					get_viewport().set_input_as_handled()
					return

			if event.position.x > get_viewport_rect().size.x * 0.40:
				touch_modes[event.index] = "look"
				get_viewport().set_input_as_handled()

		else:
			if touch_modes.has(event.index):
				var mode: String = touch_modes[event.index]
				if mode == "joystick":
					joystick_touch = -1
					move_vector = Vector2.ZERO
					joy_knob = Vector2.ZERO
				elif mode != "look":
					Input.action_release(mode)
				touch_modes.erase(event.index)
				get_viewport().set_input_as_handled()

	elif event is InputEventScreenDrag:
		if not touch_modes.has(event.index):
			return

		var mode: String = touch_modes[event.index]
		if mode == "joystick":
			_update_joystick(event.position)
			get_viewport().set_input_as_handled()
		elif mode == "look":
			look_delta += event.relative
			get_viewport().set_input_as_handled()

func _update_joystick(pos: Vector2) -> void:
	var delta := pos - joy_center
	if delta.length() > joy_radius:
		delta = delta.normalized() * joy_radius
	joy_knob = delta
	move_vector = delta / joy_radius

func _draw() -> void:
	if not OS.has_feature("web") and not OS.has_feature("mobile"):
		return

	draw_circle(joy_center, joy_radius, Color(0.02, 0.05, 0.09, 0.38))
	draw_arc(joy_center, joy_radius, 0.0, TAU, 48, Color(1, 1, 1, 0.25), 2.0)
	draw_circle(joy_center + joy_knob, 28.0, Color(1, 1, 1, 0.23))
	draw_arc(joy_center + joy_knob, 28.0, 0.0, TAU, 32, Color(1, 1, 1, 0.30), 2.0)

	var centers := _button_centers()
	_draw_button(centers["jump"], 45.0, "JUMP")
	_draw_button(centers["sprint"], 40.0, "RUN")
	_draw_button(centers["interact"], 40.0, "CAR")

func _draw_button(center: Vector2, radius: float, label: String) -> void:
	draw_circle(center, radius, Color(0.02, 0.05, 0.09, 0.58))
	draw_arc(center, radius, 0.0, TAU, 40, Color(1, 1, 1, 0.24), 2.0)
	var font := ThemeDB.fallback_font
	var font_size := 14
	var text_size := font.get_string_size(label, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size)
	draw_string(font, center - Vector2(text_size.x * 0.5, -text_size.y * 0.28),
		label, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color.WHITE)
