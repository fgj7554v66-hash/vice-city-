extends CharacterBody3D

@export var max_forward_speed := 30.0
@export var max_reverse_speed := 9.0
@export var acceleration := 18.0
@export var braking := 25.0
@export var steering_rate := 1.65
@export var coast_drag := 5.5

@onready var camera: Camera3D = $CameraPivot/SpringArm3D/Camera3D
@onready var visual: Node3D = $CarVisual

var driver: Node = null
var speed := 0.0

func _ready() -> void:
	add_to_group("cars")
	add_to_group("drivable_cars")
	camera.current = false

func enter_vehicle(player: Node) -> void:
	if driver != null:
		return
	driver = player
	if driver.has_method("enter_vehicle"):
		driver.enter_vehicle(self)
	camera.current = true

func _physics_process(delta: float) -> void:
	if driver == null:
		speed = move_toward(speed, 0.0, coast_drag * delta)
		velocity = -global_transform.basis.z * speed
		move_and_slide()
		return

	if Input.is_action_just_pressed("interact"):
		_exit_vehicle()
		return

	var throttle := Input.get_axis("move_back", "move_forward")
	var steer := Input.get_axis("move_left", "move_right")

	var mobile := get_tree().get_first_node_in_group("mobile_controls")
	if mobile != null:
		var mobile_vec: Vector2 = mobile.get_move_vector()
		if mobile_vec.length() > 0.08:
			steer = mobile_vec.x
			throttle = -mobile_vec.y

	if throttle > 0.0:
		speed = move_toward(speed, max_forward_speed, acceleration * throttle * delta)
	elif throttle < 0.0:
		if speed > 1.0:
			speed = move_toward(speed, 0.0, braking * delta)
		else:
			speed = move_toward(speed, -max_reverse_speed, acceleration * -throttle * delta)
	else:
		speed = move_toward(speed, 0.0, coast_drag * delta)

	if abs(speed) > 0.3:
		var speed_factor := clamp(abs(speed) / 12.0, 0.20, 1.0)
		rotation.y += steer * steering_rate * speed_factor * delta * sign(speed)

	velocity = -global_transform.basis.z * speed
	velocity.y -= 18.0 * delta
	move_and_slide()

	visual.rotation.z = lerp(visual.rotation.z, -steer * min(abs(speed) / 45.0, 0.075), delta * 6.0)

	var speed_hud := get_tree().get_first_node_in_group("speed_hud")
	if speed_hud != null:
		speed_hud.visible = true
		speed_hud.text = "%03d KM/H" % int(abs(speed) * 3.6)

func _exit_vehicle() -> void:
	if driver == null:
		return

	var old_driver := driver
	driver = null
	camera.current = false

	var exit_offset := global_transform.basis.x * 2.3 + Vector3.UP * 0.3
	if old_driver.has_method("exit_vehicle"):
		old_driver.exit_vehicle(global_position + exit_offset)

	var speed_hud := get_tree().get_first_node_in_group("speed_hud")
	if speed_hud != null:
		speed_hud.visible = false
