extends CharacterBody3D

@export var walk_speed := 1.25
@export var min_z := -450.0
@export var max_z := 90.0

@onready var model: Node3D = $Model
@onready var left_leg: Node3D = $Model/LeftLeg
@onready var right_leg: Node3D = $Model/RightLeg

var direction := -1.0
var phase := 0.0

func _ready() -> void:
	direction = -1.0 if randf() > 0.5 else 1.0
	rotation.y = 0.0 if direction < 0.0 else PI
	walk_speed *= randf_range(0.78, 1.22)

func _physics_process(delta: float) -> void:
	phase += delta * walk_speed * 4.8
	left_leg.rotation.x = sin(phase) * 0.52
	right_leg.rotation.x = -sin(phase) * 0.52

	velocity = Vector3(0.0, -1.0, direction * walk_speed)
	move_and_slide()

	if global_position.z < min_z:
		global_position.z = max_z
	elif global_position.z > max_z:
		global_position.z = min_z
