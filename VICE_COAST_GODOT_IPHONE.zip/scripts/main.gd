extends Node3D

const PLAYER_SCENE := preload("res://scenes/player.tscn")
const CAR_SCENE := preload("res://scenes/car.tscn")
const TRAFFIC_SCENE := preload("res://scenes/traffic_car.tscn")
const NPC_SCENE := preload("res://scenes/npc.tscn")
const TARGET_SCENE := preload("res://scenes/target.tscn")
const BUILDING_SHADER := preload("res://shaders/building.gdshader")
const OCEAN_SHADER := preload("res://shaders/ocean.gdshader")
const MOBILE_CONTROLS := preload("res://scripts/mobile_controls.gd")

var rng := RandomNumberGenerator.new()

func _ready() -> void:
	rng.seed = 7331
	_setup_environment()
	_build_ground()
	_build_roads()
	_build_city()
	_build_beach()
	_build_ocean()
	_spawn_population()
	_spawn_player_and_cars()
	_spawn_targets()
	_build_hud()
	_build_mobile_controls()


func _build_mobile_controls() -> void:
	var layer := CanvasLayer.new()
	layer.name = "MobileControlsLayer"
	layer.layer = 20
	add_child(layer)

	var controls := Control.new()
	controls.name = "MobileControls"
	controls.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	controls.script = MOBILE_CONTROLS
	layer.add_child(controls)

func _setup_environment() -> void:
	var world_env := WorldEnvironment.new()
	world_env.name = "WorldEnvironment"

	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.55
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.72, 0.82, 0.88)
	env.fog_density = 0.0018

	var sky := Sky.new()
	var sky_material := ProceduralSkyMaterial.new()
	sky_material.sky_top_color = Color(0.14, 0.46, 0.76)
	sky_material.sky_horizon_color = Color(0.72, 0.84, 0.91)
	sky_material.ground_bottom_color = Color(0.38, 0.32, 0.27)
	sky_material.ground_horizon_color = Color(0.93, 0.65, 0.45)
	sky_material.sun_angle_max = 14.0
	sky_material.sun_curve = 0.12
	sky.sky_material = sky_material
	env.sky = sky

	world_env.environment = env
	add_child(world_env)

	var sun := DirectionalLight3D.new()
	sun.name = "Sun"
	sun.rotation_degrees = Vector3(-43.0, -38.0, 0.0)
	sun.light_color = Color(1.0, 0.86, 0.69)
	sun.light_energy = 1.65
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 180.0
	add_child(sun)

func _material(color: Color, roughness := 0.85, metallic := 0.0) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = roughness
	material.metallic = metallic
	return material

func _static_box(name: String, pos: Vector3, size: Vector3, material: Material, collision := true) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = name
	body.position = pos
	add_child(body)

	var mesh_instance := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	mesh_instance.mesh = box
	mesh_instance.material_override = material
	mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	body.add_child(mesh_instance)

	if collision:
		var shape_node := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = size
		shape_node.shape = shape
		body.add_child(shape_node)

	return body

func _visual_box(pos: Vector3, size: Vector3, material: Material) -> MeshInstance3D:
	var mesh_instance := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	mesh_instance.mesh = box
	mesh_instance.material_override = material
	mesh_instance.position = pos
	mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	add_child(mesh_instance)
	return mesh_instance

func _build_ground() -> void:
	_static_box("Ground", Vector3(155.0, -0.55, -180.0), Vector3(650.0, 1.0, 760.0), _material(Color("#59754f")), true)
	_static_box("Beach", Vector3(-92.0, -0.23, -180.0), Vector3(120.0, 0.35, 760.0), _material(Color("#d2ae78")), false)
	_static_box("Promenade", Vector3(-31.0, -0.13, -180.0), Vector3(18.0, 0.22, 760.0), _material(Color("#b6b5af")), false)

func _road(x: float, z: float, width: float, depth: float, vertical := true) -> void:
	var asphalt := _material(Color("#292c31"), 0.96, 0.0)
	_static_box("Road", Vector3(x, -0.08, z), Vector3(width, 0.12, depth), asphalt, false)

	var white := _material(Color("#e9e5d8"), 0.78)
	var yellow := _material(Color("#d7ae43"), 0.74)

	if vertical:
		_visual_box(Vector3(x - width * 0.5 + 1.1, 0.02, z), Vector3(0.14, 0.04, depth - 1.0), white)
		_visual_box(Vector3(x + width * 0.5 - 1.1, 0.02, z), Vector3(0.14, 0.04, depth - 1.0), white)
		var zz := z - depth * 0.5 + 7.0
		while zz < z + depth * 0.5:
			_visual_box(Vector3(x, 0.025, zz), Vector3(0.12, 0.045, 5.0), yellow)
			zz += 13.0
	else:
		_visual_box(Vector3(x, 0.02, z - depth * 0.5 + 1.1), Vector3(width - 1.0, 0.04, 0.14), white)
		_visual_box(Vector3(x, 0.02, z + depth * 0.5 - 1.1), Vector3(width - 1.0, 0.04, 0.14), white)
		var xx := x - width * 0.5 + 7.0
		while xx < x + width * 0.5:
			_visual_box(Vector3(xx, 0.025, z), Vector3(5.0, 0.045, 0.12), yellow)
			xx += 13.0

func _build_roads() -> void:
	for x in [15.0, 96.0, 177.0, 258.0]:
		_road(x, -180.0, 25.0, 700.0, true)

	for z in [55.0, -25.0, -105.0, -185.0, -265.0, -345.0, -425.0]:
		_road(140.0, z, 310.0, 23.0, false)

func _building_material(base: Color, seed: float, floors: float) -> ShaderMaterial:
	var material := ShaderMaterial.new()
	material.shader = BUILDING_SHADER
	material.set_shader_parameter("base_color", base)
	material.set_shader_parameter("glass_color", Color("#16394d"))
	material.set_shader_parameter("columns", rng.randf_range(5.0, 9.0))
	material.set_shader_parameter("floors", floors)
	material.set_shader_parameter("seed", seed)
	return material

func _building(pos: Vector3, size: Vector3, color: Color, seed: float) -> void:
	var floors := clamp(size.y / 4.7, 5.0, 28.0)
	var material := _building_material(color, seed, floors)
	_static_box("Building", Vector3(pos.x, size.y * 0.5, pos.z), size, material, true)

	if size.y > 55.0:
		_visual_box(Vector3(pos.x, size.y + 0.8, pos.z), Vector3(size.x * 0.38, 1.6, size.z * 0.35), _material(Color("#656a6d")))

func _build_city() -> void:
	var x_lots := [55.0, 136.0, 217.0, 298.0]
	var palette := [
		Color("#aaa69d"),
		Color("#b9b5ab"),
		Color("#8f9fa4"),
		Color("#c1b8a8"),
		Color("#9ca5a5"),
		Color("#b2a58f")
	]
	var seed := 1.0

	for x in x_lots:
		for z in range(-385, 22, 80):
			if rng.randf() < 0.08:
				continue

			var w := rng.randf_range(31.0, 46.0)
			var d := rng.randf_range(31.0, 46.0)
			var h := rng.randf_range(28.0, 66.0)

			if x > 170.0 and rng.randf() > 0.42:
				h = rng.randf_range(68.0, 132.0)

			_building(Vector3(x + rng.randf_range(-3.0, 3.0), 0.0, z + rng.randf_range(-4.0, 4.0)), Vector3(w, h, d), palette[rng.randi_range(0, palette.size() - 1)], seed)
			seed += 1.0

	_building(Vector3(298.0, 0.0, -185.0), Vector3(46.0, 155.0, 44.0), Color("#a9b1b3"), 90.0)
	_building(Vector3(217.0, 0.0, -345.0), Vector3(43.0, 138.0, 40.0), Color("#bdbbb3"), 91.0)

func _palm(x: float, z: float, scale := 1.0) -> void:
	var root := Node3D.new()
	root.position = Vector3(x, 0.0, z)
	root.scale = Vector3.ONE * scale
	add_child(root)

	var trunk := MeshInstance3D.new()
	var trunk_mesh := CylinderMesh.new()
	trunk_mesh.top_radius = 0.18
	trunk_mesh.bottom_radius = 0.30
	trunk_mesh.height = 7.0
	trunk.mesh = trunk_mesh
	trunk.material_override = _material(Color("#775035"))
	trunk.position.y = 3.5
	trunk.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	root.add_child(trunk)

	for i in range(8):
		var leaf := MeshInstance3D.new()
		var leaf_mesh := BoxMesh.new()
		leaf_mesh.size = Vector3(0.18, 0.10, 3.7)
		leaf.mesh = leaf_mesh
		leaf.material_override = _material(Color("#27733f") if i % 2 == 0 else Color("#1f5e36"))
		var angle := float(i) * TAU / 8.0
		leaf.position = Vector3(sin(angle) * 1.5, 7.05, cos(angle) * 1.5)
		leaf.rotation = Vector3(rng.randf_range(-0.15, 0.08), angle, rng.randf_range(-0.12, 0.12))
		leaf.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
		root.add_child(leaf)

func _bench(x: float, z: float) -> void:
	var wood := _material(Color("#704526"))
	var metal := _material(Color("#2e3338"), 0.62, 0.2)
	_visual_box(Vector3(x, 0.55, z), Vector3(2.2, 0.16, 0.45), wood)
	_visual_box(Vector3(x, 1.00, z + 0.18), Vector3(2.2, 0.70, 0.13), wood)
	_visual_box(Vector3(x - 0.72, 0.35, z), Vector3(0.10, 0.7, 0.10), metal)
	_visual_box(Vector3(x + 0.72, 0.35, z), Vector3(0.10, 0.7, 0.10), metal)

func _umbrella(x: float, z: float, color: Color) -> void:
	var pole := MeshInstance3D.new()
	var pole_mesh := CylinderMesh.new()
	pole_mesh.top_radius = 0.035
	pole_mesh.bottom_radius = 0.035
	pole_mesh.height = 2.2
	pole.mesh = pole_mesh
	pole.material_override = _material(Color("#606060"), 0.7, 0.25)
	pole.position = Vector3(x, 1.1, z)
	add_child(pole)

	var canopy := MeshInstance3D.new()
	var cone := CylinderMesh.new()
	cone.top_radius = 0.0
	cone.bottom_radius = 1.55
	cone.height = 0.42
	canopy.mesh = cone
	canopy.material_override = _material(color, 0.58)
	canopy.position = Vector3(x, 2.28, z)
	add_child(canopy)

func _build_beach() -> void:
	for z in range(-470, 105, 29):
		_palm(-51.0 + rng.randf_range(-2.5, 2.5), float(z) + rng.randf_range(-4.0, 4.0), rng.randf_range(0.82, 1.08))
		if rng.randf() > 0.42:
			_palm(-105.0 + rng.randf_range(-18.0, 16.0), float(z) + rng.randf_range(-8.0, 8.0), rng.randf_range(0.72, 1.0))

	for z in range(-425, 70, 72):
		_bench(-26.0, float(z))

	var colors := [Color("#d95145"), Color("#deb644"), Color("#3e86b0"), Color("#dedad0")]
	for z in range(-420, 80, 60):
		if rng.randf() > 0.16:
			_umbrella(-108.0 + rng.randf_range(-18.0, 15.0), float(z), colors[rng.randi_range(0, colors.size() - 1)])

func _build_ocean() -> void:
	var ocean := MeshInstance3D.new()
	ocean.name = "Ocean"
	var ocean_mesh := PlaneMesh.new()
	ocean_mesh.size = Vector2(520.0, 760.0)
	ocean_mesh.subdivide_width = 80
	ocean_mesh.subdivide_depth = 100
	ocean.mesh = ocean_mesh

	var material := ShaderMaterial.new()
	material.shader = OCEAN_SHADER
	ocean.material_override = material
	ocean.position = Vector3(-385.0, -0.06, -180.0)
	ocean.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(ocean)

func _spawn_population() -> void:
	var sidewalks := [-18.0, 35.0, 75.0, 116.0, 156.0, 197.0, 237.0, 278.0]

	for i in range(28):
		var npc := NPC_SCENE.instantiate()
		npc.position = Vector3(sidewalks[rng.randi_range(0, sidewalks.size() - 1)] + rng.randf_range(-2.0, 2.0), 0.0, rng.randf_range(-440.0, 80.0))
		add_child(npc)

func _spawn_player_and_cars() -> void:
	var player := PLAYER_SCENE.instantiate()
	player.position = Vector3(18.0, 0.2, 72.0)
	add_child(player)

	var hero_car := CAR_SCENE.instantiate()
	hero_car.position = Vector3(30.0, 0.25, 53.0)
	hero_car.rotation.y = PI
	add_child(hero_car)

	var lanes := [10.0, 20.0, 91.0, 101.0, 172.0, 182.0, 253.0, 263.0]
	for i in range(14):
		var traffic := TRAFFIC_SCENE.instantiate()
		traffic.position = Vector3(lanes[rng.randi_range(0, lanes.size() - 1)], 0.15, rng.randf_range(-455.0, 95.0))
		traffic.travel_direction = -1.0 if i % 2 == 0 else 1.0
		traffic.speed = rng.randf_range(8.0, 14.0)
		add_child(traffic)

func _spawn_targets() -> void:
	for i in range(4):
		var target := TARGET_SCENE.instantiate()
		target.position = Vector3(-15.0, 0.0, -35.0 - i * 9.0)
		add_child(target)

func _build_hud() -> void:
	var layer := CanvasLayer.new()
	layer.name = "HUD"
	add_child(layer)

	var brand := Label.new()
	brand.text = "VICE COAST"
	brand.position = Vector2(20, 18)
	brand.add_theme_font_size_override("font_size", 26)
	layer.add_child(brand)

	var instructions := Label.new()
	instructions.text = "IPHONE: LEFT STICK MOVE • SWIPE RIGHT TO LOOK • RUN • JUMP • CAR" if OS.has_feature("web") or OS.has_feature("mobile") else "WASD MOVE • MOUSE LOOK • SHIFT SPRINT • SPACE JUMP • E CAR"
	instructions.position = Vector2(22, 54)
	instructions.modulate = Color(1, 1, 1, 0.68)
	instructions.add_theme_font_size_override("font_size", 13)
	layer.add_child(instructions)


	var speed := Label.new()
	speed.text = "000 KM/H"
	speed.position = Vector2(1070, 54)
	speed.visible = false
	speed.add_to_group("speed_hud")
	speed.add_theme_font_size_override("font_size", 18)
	layer.add_child(speed)

	var crosshair := Label.new()
	crosshair.text = "+"
	crosshair.set_anchors_preset(Control.PRESET_CENTER)
	crosshair.position = Vector2(-7, -18)
	crosshair.add_theme_font_size_override("font_size", 30)
	layer.add_child(crosshair)

	var hint := Label.new()
	hint.text = "Red coupe near spawn is drivable. Walk the boulevard or take it for a drive."
	hint.position = Vector2(20, 680)
	hint.modulate = Color(1, 1, 1, 0.62)
	hint.add_theme_font_size_override("font_size", 12)
	layer.add_child(hint)
