extends CharacterBody3D

@export var walk_speed := 6.0
@export var sprint_speed := 10.0
@export var acceleration := 18.0
@export var jump_velocity := 7.0
@export var mouse_sensitivity := 0.0026
@export var interact_distance := 4.2

@onready var model: Node3D = $Model
@onready var camera_pivot: Node3D = $CameraPivot
@onready var camera: Camera3D = $CameraPivot/SpringArm3D/Camera3D

var gravity := 19.0
var camera_yaw := 0.0
var camera_pitch := -0.16
var active := true
var current_vehicle: Node = null

func _ready() -> void:
	add_to_group("player")
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	camera.current = true

func _unhandled_input(event: InputEvent) -> void:
	if not active:
		return

	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		camera_yaw -= event.relative.x * mouse_sensitivity
		camera_pitch = clamp(camera_pitch - event.relative.y * mouse_sensitivity, -0.95, 0.35)
		camera_pivot.rotation = Vector3(camera_pitch, camera_yaw, 0.0)

	if event.is_action_pressed("ui_cancel"):
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED else Input.MOUSE_MODE_CAPTURED

func _physics_process(delta: float) -> void:
	if not active:
		return

	var input_vec := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var mobile := get_tree().get_first_node_in_group("mobile_controls")
	if mobile != null:
		var mobile_vec: Vector2 = mobile.get_move_vector()
		if mobile_vec.length() > input_vec.length():
			input_vec = mobile_vec

		var touch_look: Vector2 = mobile.consume_look_delta()
		camera_yaw -= touch_look.x * mouse_sensitivity * 1.25
		camera_pitch = clamp(camera_pitch - touch_look.y * mouse_sensitivity * 1.05, -0.95, 0.35)
		camera_pivot.rotation = Vector3(camera_pitch, camera_yaw, 0.0)

	var local_dir := Vector3(input_vec.x, 0.0, input_vec.y)
	var world_dir := local_dir.rotated(Vector3.UP, camera_yaw).normalized()

	var target_speed := sprint_speed if Input.is_action_pressed("sprint") else walk_speed
	var desired := world_dir * target_speed

	velocity.x = move_toward(velocity.x, desired.x, acceleration * delta)
	velocity.z = move_toward(velocity.z, desired.z, acceleration * delta)

	if not is_on_floor():
		velocity.y -= gravity * delta
	elif Input.is_action_just_pressed("jump"):
		velocity.y = jump_velocity

	if world_dir.length_squared() > 0.02:
		var facing := atan2(world_dir.x, world_dir.z)
		model.rotation.y = lerp_angle(model.rotation.y, facing, min(1.0, delta * 10.0))

	move_and_slide()

	if Input.is_action_just_pressed("interact"):
		_try_enter_vehicle()

	if Input.is_action_pressed("fire") and shoot_cooldown <= 0.0:
		_fire()

	if Input.is_action_just_pressed("reload"):
		ammo = 24
	
func _try_enter_vehicle() -> void:
	var closest: Node3D = null
	var best_distance := interact_distance

	for car in get_tree().get_nodes_in_group("drivable_cars"):
		if not car is Node3D:
			continue
		var d := global_position.distance_to(car.global_position)
		if d < best_distance:
			best_distance = d
			closest = car

	if closest != null and closest.has_method("enter_vehicle"):
		closest.enter_vehicle(self)

func enter_vehicle(car: Node) -> void:
	current_vehicle = car
	active = false
	visible = false
	collision_layer = 0
	collision_mask = 0
	camera.current = false
	velocity = Vector3.ZERO

func exit_vehicle(exit_position: Vector3) -> void:
	current_vehicle = null
	global_position = exit_position
	visible = true
	collision_layer = 2
	collision_mask = 1
	camera.current = true
	active = true

