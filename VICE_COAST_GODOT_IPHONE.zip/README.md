# Vice Coast — Godot 4 Project

This is a real Godot project, not a browser game.

## What is already built

- Third-person character controller
- Mouse camera
- Sprint + jump
- Arcade raycast weapon with ammo/reload and visible tracer
- Non-graphic shootable target boards
- Drivable red coupe with enter/exit system
- Traffic cars
- Pedestrian NPCs
- Procedural city blocks with window shader
- Roads, lane markings and building collisions
- Beach district with palms, umbrellas and benches
- Animated ocean shader
- Directional sunlight, shadows, sky and fog
- HUD, crosshair, ammo and vehicle speed display
- Separate reusable scenes/scripts instead of one giant file

## Controls

- **WASD** — move / drive
- **Mouse** — camera
- **Shift** — sprint
- **Space** — jump
- **E** — enter/exit the red car
- **Left click** — fire the arcade weapon
- **R** — reload
- **Esc** — release/capture mouse

## Open it

1. Install/open **Godot 4.x** on a computer.
2. Choose **Import** or **Scan**.
3. Select this folder's `project.godot`.
4. Open the project.
5. Press **F6/F5** to run.

The project uses only built-in meshes and shaders, so there are no paid assets or missing downloads.

## Where to upgrade graphics later

Drop real `.glb` / `.gltf` models into `assets/` and replace:
- `scenes/car_visual.tscn`
- the procedural building meshes in `scripts/main.gd`
- the primitive NPC model in `scenes/npc.tscn`
- the player model in `scenes/player.tscn`

That is the important difference from the old HTML version: this project is structured so real models, animations, textures, audio, missions and a bigger map can be added without rewriting everything.
